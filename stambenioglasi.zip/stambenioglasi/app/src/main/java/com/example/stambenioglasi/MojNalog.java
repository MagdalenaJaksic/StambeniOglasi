package com.example.stambenioglasi;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MojNalog extends AppCompatActivity implements OglasiAdapter2.OnOglasDeleteListener,OglasiAdapter2.OnOglasEditListener {
    private static final int EDIT_OGLAS_REQUEST_CODE = 1;
    private TextView textViewKorisnickoIme;
    private RecyclerView recyclerViewOglasi;
    private OglasiAdapter2 oglasiAdapter2;
    private Button buttonOdjava;
    private DatabaseHelper databaseHelper;

    //DA SE OSVEZI LISTA KAD SE UPDATE-UJU
    private final ActivityResultLauncher<Intent> editOglasLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    updateOglasiList();
                }
            }
    );

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.moj_nalog);

        buttonOdjava=findViewById(R.id.buttonOdjava);
        textViewKorisnickoIme = findViewById(R.id.textViewKorisnickoIme);
        recyclerViewOglasi = findViewById(R.id.recyclerViewOglasi);
        databaseHelper = new DatabaseHelper(this);


        Intent intent = getIntent();
        String username = intent.getStringExtra("KORISNICKO_IME");
        String username2 = intent.getStringExtra("KORISNICKO_IME2");

        if (username != null) {
            textViewKorisnickoIme.setText(username);
        } else if (username2 != null) {
            textViewKorisnickoIme.setText(username2);
        }

        String korisnickoIme = textViewKorisnickoIme.getText().toString();
        List<Oglas> oglasiKorisnika = databaseHelper.getOglasiByVlasnik(korisnickoIme);

        //RECYCLER VIEW ZA LISTU OGLASA PO KORISNIKU
        recyclerViewOglasi.setLayoutManager(new LinearLayoutManager(this));
        oglasiAdapter2 = new OglasiAdapter2(this, oglasiKorisnika, this,this);
        oglasiAdapter2.setOnOglasEditListener(this);
        recyclerViewOglasi.setAdapter(oglasiAdapter2);


        buttonOdjava.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent odjavaintent=new Intent(MojNalog.this,LoginActivity.class);
                startActivity(odjavaintent);

            }
        });


    }


    @Override
    public void onOglasDelete(int position) {
        Oglas oglas = oglasiAdapter2.getOglasiList().get(position);
        databaseHelper.deleteOglas(oglas.getId());

        // AZURIRA SE LISTA I OBAVESTAVA ADAPTER
        oglasiAdapter2.getOglasiList().remove(position);
        recyclerViewOglasi.getAdapter().notifyItemRemoved(position);
        // ZA MAIN
        setResult(RESULT_OK);
        finish();
    }
    @Override
    public void onOglasEdit(int position) {
        Oglas oglas = oglasiAdapter2.getOglasiList().get(position);
        //POKRECE SE IZMENI OGLAS I PROSLEDJUJE ID OGLASA
        Intent editIntent = new Intent(this, IzmeniOglasActivity.class);
        editIntent.putExtra("OGLAS_ID", oglas.getId());
        editOglasLauncher.launch(editIntent);

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == EDIT_OGLAS_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                updateOglasiList();
            }
        }
    }

    //OVO OBAVESTAVA MAIN I ADAPTER U MOJ NALOG DA JE IZMENJEN OGLAS
    private void updateOglasiList() {
        String korisnickoIme = textViewKorisnickoIme.getText().toString();
        List<Oglas> oglasiKorisnika = databaseHelper.getOglasiByVlasnik(korisnickoIme);
        if (MainActivity.oglasChangeListener != null) {
            MainActivity.oglasChangeListener.onOglasChanged();
            oglasiAdapter2.setOglasiList(oglasiKorisnika);
            oglasiAdapter2.notifyDataSetChanged();
        }

    }
}
