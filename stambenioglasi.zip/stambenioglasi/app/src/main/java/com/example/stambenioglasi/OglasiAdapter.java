package com.example.stambenioglasi;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class OglasiAdapter extends RecyclerView.Adapter<OglasiAdapter.OglasViewHolder> {

    private Context context;
    private List<Oglas> oglasiList;

    public OglasiAdapter(Context context, List<Oglas> oglasiList) {
        this.context = context;
        this.oglasiList = oglasiList;
    }

    @Override
    public OglasViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_oglas, parent, false);
        return new OglasViewHolder(view);
    }

    @Override
    public void onBindViewHolder(OglasViewHolder holder, int position) {
        Oglas oglas = oglasiList.get(position);

        holder.textViewLokacija.setText(oglas.getLokacija());
        holder.textViewNaselje.setText(oglas.getNaselje());
        holder.textViewCena.setText(String.valueOf(oglas.getCena()));
        holder.textViewBrojSoba.setText(String.valueOf(oglas.getBrojSoba()));

        // Konvertuj bajtove slike u Bitmap i postavi je na ImageView
        if (oglas.getSlika() != null) {
            Bitmap bitmap = BitmapFactory.decodeByteArray(oglas.getSlika(), 0, oglas.getSlika().length);
            holder.imageViewSlika.setImageBitmap(bitmap);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pokrećemo aktivnost za prikaz detalja oglasa
                Intent intent = new Intent(context, DetaljiOglasaActivity.class);
                intent.putExtra("ID",oglas.getId());
                intent.putExtra("LOKACIJA", oglas.getLokacija());
                intent.putExtra("NASELJE", oglas.getNaselje());
                intent.putExtra("CENA", oglas.getCena());
                intent.putExtra("BROJSOBA", oglas.getBrojSoba());
                intent.putExtra("KONTAKT", oglas.getKontakt());
                intent.putExtra("OPIS", oglas.getOpis());


                // Dodajte sve potrebne informacije koje želite proslediti na aktivnost detalja oglasa
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return oglasiList.size();
    }
    public void setOglasiList(List<Oglas> oglasiList) {
        this.oglasiList = oglasiList;
    }
    public List<Oglas> getOglasiList() {
        return oglasiList;
    }

    public class OglasViewHolder extends RecyclerView.ViewHolder {
        TextView textViewLokacija, textViewNaselje, textViewCena, textViewBrojSoba;
        ImageView imageViewSlika;

        public OglasViewHolder(View itemView) {
            super(itemView);
            textViewLokacija = itemView.findViewById(R.id.textViewLokacija);
            textViewNaselje = itemView.findViewById(R.id.textViewNaselje);
            textViewCena = itemView.findViewById(R.id.textViewCena);
            textViewBrojSoba = itemView.findViewById(R.id.textViewBrojSoba);
            imageViewSlika = itemView.findViewById(R.id.imageViewSlika);
        }
    }
}
