package com.example.stambenioglasi;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "OglasiDB";
    private static final int DATABASE_VERSION = 1;

    //TABELA OGLASI
    public static final String TABLE_OGLASI = "Oglasi";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_LOKACIJA = "lokacija";
    public static final String COLUMN_NASELJE = "naselje";
    public static final String COLUMN_CENA = "cena";
    public static final String COLUMN_BROJ_SOBA = "broj_soba";
    public static final String COLUMN_OPIS = "opis";
    public static final String COLUMN_KONTAKT = "kontakt";
    public static final String COLUMN_VLASNIK = "vlasnik";
    public static final String COLUMN_SLIKA = "slika";
    private static final String CREATE_TABLE_OGLASI =
            "CREATE TABLE " + TABLE_OGLASI + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_LOKACIJA + " TEXT," +
                    COLUMN_NASELJE + " TEXT," +
                    COLUMN_CENA + " INTEGER," +
                    COLUMN_BROJ_SOBA + " INTEGER," +
                    COLUMN_OPIS + " TEXT," +
                    COLUMN_KONTAKT + " TEXT," +
                    COLUMN_VLASNIK + " TEXT," +
                    COLUMN_SLIKA + " BLOB" +
                    ");";

    // REGISTRACIJA-NALOZI
    public static final String TABLE_NALOZI = "nalozi";
    public static final String COLUMN_ID_NALOZI = "id_naloga";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_PASSWORD = "password";
    private static final String CREATE_TABLE_NALOZI = "CREATE TABLE " + TABLE_NALOZI +
            "(" +
            COLUMN_ID_NALOZI + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_USERNAME + " TEXT, " +
            COLUMN_EMAIL + " TEXT, " +
            COLUMN_PASSWORD + " TEXT" +
            ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_OGLASI);
        db.execSQL(CREATE_TABLE_NALOZI);
    }
    public void updateDatabase(SQLiteDatabase db) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_OGLASI);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NALOZI);
        onCreate(db);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        updateDatabase(db);
    }


//DODAVANJE NALOGA PRI REGISTRACIJI
    public long addNalog(String username, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_NALOZI, null, values);
        db.close();
        return result;
    }
    public boolean checkUsernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_NALOZI,
                new String[]{COLUMN_ID_NALOZI},
                COLUMN_USERNAME + "=?",
                new String[]{username},
                null,
                null,
                null,
                null
        );

        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    //PROVERA ZA LOGOVANJE
    public boolean checkLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_NALOZI,
                new String[]{COLUMN_ID_NALOZI},
                COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password},
                null,
                null,
                null,
                null
        );

        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

//SVI OGLASI IZ BAZE
    public List<Oglas> getAllOglasi() {
        List<Oglas> oglasiList = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_OGLASI,
                null,
                null,
                null,
                null,
                null,
                null,
                null
        );

        if (cursor != null && cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndex(COLUMN_ID));
                String lokacija = cursor.getString(cursor.getColumnIndex(COLUMN_LOKACIJA));
                String naselje = cursor.getString(cursor.getColumnIndex(COLUMN_NASELJE));
                int cena = cursor.getInt(cursor.getColumnIndex(COLUMN_CENA));
                int brojSoba = cursor.getInt(cursor.getColumnIndex(COLUMN_BROJ_SOBA));
                String opis = cursor.getString(cursor.getColumnIndex(COLUMN_OPIS));
                String kontakt = cursor.getString(cursor.getColumnIndex(COLUMN_KONTAKT));
                String vlasnik = cursor.getString(cursor.getColumnIndex(COLUMN_VLASNIK));
                byte[] slika = cursor.getBlob(cursor.getColumnIndex(COLUMN_SLIKA));

                Oglas oglas = new Oglas(id, lokacija, naselje, cena, brojSoba, opis, kontakt, vlasnik, slika);
                oglasiList.add(oglas);
            } while (cursor.moveToNext());

            cursor.close();
        }

        db.close();
        return oglasiList;
    }

    //DOBIJANJE OGLASA ODREDJENOG VLASNIKA
    public List<Oglas> getOglasiByVlasnik(String vlasnik) {
        List<Oglas> oglasiList = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {
                COLUMN_ID,
                COLUMN_LOKACIJA,
                COLUMN_NASELJE,
                COLUMN_CENA,
                COLUMN_BROJ_SOBA,
                COLUMN_OPIS,
                COLUMN_KONTAKT,
                COLUMN_VLASNIK,
                COLUMN_SLIKA
        };
        String selection = COLUMN_VLASNIK + " = ?";
        String[] selectionArgs = {vlasnik};

        Cursor cursor = db.query(
                TABLE_OGLASI,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        if (cursor != null && cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndex(COLUMN_ID));
                String lokacija = cursor.getString(cursor.getColumnIndex(COLUMN_LOKACIJA));
                String naselje = cursor.getString(cursor.getColumnIndex(COLUMN_NASELJE));
                int cena = cursor.getInt(cursor.getColumnIndex(COLUMN_CENA));
                int brojSoba = cursor.getInt(cursor.getColumnIndex(COLUMN_BROJ_SOBA));
                String opis = cursor.getString(cursor.getColumnIndex(COLUMN_OPIS));
                String kontakt = cursor.getString(cursor.getColumnIndex(COLUMN_KONTAKT));
                String vlasnikOglasa = cursor.getString(cursor.getColumnIndex(COLUMN_VLASNIK));
                byte[] slika = cursor.getBlob(cursor.getColumnIndex(COLUMN_SLIKA));

                Oglas oglas = new Oglas(id, lokacija, naselje, cena, brojSoba, opis, kontakt, vlasnikOglasa, slika);
                oglasiList.add(oglas);
            } while (cursor.moveToNext());

            cursor.close();
        }

        db.close();
        return oglasiList;
    }
    //BRISANJE OGLASA
    public void deleteOglas(long oglasId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_OGLASI, COLUMN_ID + " = ?", new String[]{String.valueOf(oglasId)});
        db.close();
    }
    //ZA SLIKU IZ BAZE JER NE MOZE PREKO INTENT-A
    public byte[] getSlikaById(long oglasId) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {COLUMN_SLIKA};
        String selection = COLUMN_ID + " = ?";
        String[] selectionArgs = {String.valueOf(oglasId)};

        Cursor cursor = db.query(
                TABLE_OGLASI,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        byte[] slikaByteArray = null;
        if (cursor != null && cursor.moveToFirst()) {
            slikaByteArray = cursor.getBlob(cursor.getColumnIndex(COLUMN_SLIKA));
            cursor.close();
        }

        db.close();
        return slikaByteArray;
    }

    //ZA IZMENU OGLASA
    public void updateOglas(long oglasId, String lokacija, String naselje, int cena, int brojSoba, String opis, String kontakt) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_LOKACIJA, lokacija);
        values.put(COLUMN_NASELJE, naselje);
        values.put(COLUMN_CENA, cena);
        values.put(COLUMN_BROJ_SOBA, brojSoba);
       values.put(COLUMN_OPIS,opis);
       values.put(COLUMN_KONTAKT,kontakt);

        db.update(TABLE_OGLASI, values, COLUMN_ID + " = ?", new String[]{String.valueOf(oglasId)});

        db.close();
    }
    //UZIMANJE OGLASA ZA IZMENU
    public Oglas getOglasById(long oglasId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_OGLASI,
                new String[]{COLUMN_ID, COLUMN_LOKACIJA, COLUMN_NASELJE, COLUMN_CENA, COLUMN_BROJ_SOBA, COLUMN_OPIS,COLUMN_KONTAKT, COLUMN_SLIKA},
                COLUMN_ID + " = ?",
                new String[]{String.valueOf(oglasId)},
                null, null, null, null);

        Oglas oglas = null;

        if (cursor != null && cursor.moveToFirst()) {
            // Use the constructor with arguments to create a new Oglas instance
            oglas = new Oglas(
                    cursor.getLong(cursor.getColumnIndex(COLUMN_ID)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_LOKACIJA)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_NASELJE)),
                    cursor.getInt(cursor.getColumnIndex(COLUMN_CENA)),
                    cursor.getInt(cursor.getColumnIndex(COLUMN_BROJ_SOBA)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_OPIS)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_KONTAKT)),
                    null,  // Add other parameters if needed
                    cursor.getBlob(cursor.getColumnIndex(COLUMN_SLIKA))
            );
        }

        if (cursor != null) {
            cursor.close();
        }

        db.close();

        return oglas;
    }

}



