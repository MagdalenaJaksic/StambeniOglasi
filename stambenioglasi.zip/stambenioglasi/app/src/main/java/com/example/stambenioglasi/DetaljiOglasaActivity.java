package com.example.stambenioglasi;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DetaljiOglasaActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalji_oglasa);
        DatabaseHelper databaseHelper=new DatabaseHelper(this);

        // INFORMACIJE O OGLASU IZ INTENT-A
        Intent intent = getIntent();
        String lokacija = intent.getStringExtra("LOKACIJA");
        String naselje = intent.getStringExtra("NASELJE");
        int cena = intent.getIntExtra("CENA", 0);
        int brojsoba=intent.getIntExtra("BROJSOBA",0);
        String opis=intent.getStringExtra("OPIS");
        String kontakt=intent.getStringExtra("KONTAKT");

        //PRIKAZ
        TextView textViewLokacija = findViewById(R.id.textViewLokacija);
        TextView textViewNaselje = findViewById(R.id.textViewNaselje);
        TextView textViewCena = findViewById(R.id.textViewCena);
        TextView textViewbrojsoba=findViewById(R.id.textViewBrojSoba);
        TextView textViewkontakt=findViewById(R.id.textViewKontakt);
        TextView textViewopis=findViewById(R.id.textViewOpis);

        textViewLokacija.setText(lokacija);
        textViewNaselje.setText(naselje);
        textViewCena.setText(String.valueOf(cena));
       textViewbrojsoba.setText(String.valueOf(brojsoba));
       textViewkontakt.setText(kontakt);
       textViewopis.setText(opis);


        ImageView imageViewSlika = findViewById(R.id.imageViewSlika);
        long oglasId = intent.getLongExtra("ID", -1);

 //UZIMANJE SLIKE PREKO METODE
        if (oglasId != -1) {
            byte[] slikaByteArray = databaseHelper.getSlikaById(oglasId);

            if (slikaByteArray != null) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(slikaByteArray, 0, slikaByteArray.length);
                imageViewSlika.setImageBitmap(bitmap);
            }
        }
    }
    }

