package com.example.stambenioglasi;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class DodajOglasActivity extends AppCompatActivity {

    private EditText editTextLokacija, editTextNaselje, editTextCena, editTextBrojSoba, editTextOpis, editTextKontakt, editTextVlasnik;
    private ImageView imageViewSlikaOglasa;
    private Button btnDodajSliku, btnDodajOglasUBazu, btnNazad;
    private Bitmap selectedImage;
    DatabaseHelper databaseHelper;

    //POKRETANJE AKTIVNOSTI ZA BIRANJE SLIKE
    private final ActivityResultLauncher<String> launcher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    try {
                        selectedImage = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                        imageViewSlikaOglasa.setImageBitmap(selectedImage);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_oglas);

        editTextLokacija = findViewById(R.id.editTextLokacija);
        editTextNaselje = findViewById(R.id.editTextNaselje);
        editTextCena = findViewById(R.id.editTextCena);
        editTextBrojSoba = findViewById(R.id.editTextBrojSoba);
        editTextOpis = findViewById(R.id.editTextOpis);
        editTextKontakt = findViewById(R.id.editTextKontakt);
        imageViewSlikaOglasa = findViewById(R.id.imageViewSlikaOglasa);
        btnDodajSliku = findViewById(R.id.btnDodajSliku);
        btnDodajOglasUBazu = findViewById(R.id.btnDodajOglasUBazu);
        btnNazad = findViewById(R.id.btnNazad);
        databaseHelper=new DatabaseHelper(this);

        //DOBIJANJE KORISNICKOG IMENA IZ INTENT-A, MORA DVA PUTA JER SE GUBI
        Intent intent = getIntent();
        String korisnickoIme = intent.getStringExtra("KORISNICKO_IME");
        String korisnickoIme2=intent.getStringExtra("KORISNICKO_IME2");
        editTextVlasnik=findViewById(R.id.editTextVlasnik);
        editTextVlasnik.setText(korisnickoIme);

        if (korisnickoIme != null) {
            editTextVlasnik.setText(korisnickoIme);
        } else if (korisnickoIme2 != null) {
            editTextVlasnik.setText(korisnickoIme2);
        }




        btnDodajSliku.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odaberiSliku();
            }
        });

        //DODAVANJE OGLASA I PROSLEDJIVANJE IMENA U MAIN DA SE NE GUBI
        btnDodajOglasUBazu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dodajOglasUBazu();
                String ime=editTextVlasnik.getText().toString();
                Intent intent1=new Intent(DodajOglasActivity.this,MainActivity.class);
                intent1.putExtra("IME_VLASNIKA",ime);
                startActivity(intent1);
            }
        });

        btnNazad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    //POKRECE SE GORE DEFINISAN LAUNCHER ZA SLIKU
    private void odaberiSliku() {
        launcher.launch("image/*");
    }

    private void dodajOglasUBazu() {
        String lokacija = editTextLokacija.getText().toString().trim();
        String naselje = editTextNaselje.getText().toString().trim();
        int cena = Integer.parseInt(editTextCena.getText().toString().trim());
        int brojSoba = Integer.parseInt(editTextBrojSoba.getText().toString().trim());
        String opis = editTextOpis.getText().toString().trim();
        String kontakt = editTextKontakt.getText().toString().trim();
        String vlasnik= editTextVlasnik.getText().toString().trim();

        byte[] imageBytes = null;
        if (selectedImage != null) {
            imageBytes = convertBitmapToBytes(selectedImage);
        }

        if (!lokacija.isEmpty() && !naselje.isEmpty()) {
            DatabaseHelper databaseHelper = new DatabaseHelper(this);
            ContentValues values = new ContentValues();
            values.put("lokacija", lokacija);
            values.put("naselje", naselje);
            values.put("cena", cena);
            values.put("broj_soba", brojSoba);
            values.put("opis", opis);
            values.put("kontakt", kontakt);
            values.put("vlasnik", vlasnik);
            values.put("slika", imageBytes);

            long newRowId = databaseHelper.getWritableDatabase().insert("Oglasi", null, values);

            if (newRowId != -1) {
                Intent intent = new Intent(DodajOglasActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(DodajOglasActivity.this, "Greška pri dodavanju oglasa.", Toast.LENGTH_SHORT).show();
            }
        }
    }
//KONVERTOVANJE SLIKE U BYTEARRAY DA BI SE DODALA U BAZU
    private byte[] convertBitmapToBytes(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return stream.toByteArray();
    }
}
