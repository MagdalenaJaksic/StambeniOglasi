package com.example.stambenioglasi;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class OglasiAdapter2 extends RecyclerView.Adapter<OglasiAdapter2.OglasViewHolder> {

    private Context context;
    private List<Oglas> oglasiList;
    private OnOglasDeleteListener onOglasDeleteListener;
    private OnOglasEditListener onOglasEditListener;

    public void setOnOglasEditListener(OnOglasEditListener listener) {
        this.onOglasEditListener = listener;
    }

    public interface OnOglasDeleteListener {
        void onOglasDelete(int position);
    }
    public interface OnOglasEditListener {
        void onOglasEdit(int position);
    }
    public OglasiAdapter2(Context context, List<Oglas> oglasiList,OnOglasDeleteListener onOglasDeleteListener,OnOglasEditListener onOglasEditListener) {
        this.context = context;
        this.oglasiList = oglasiList;
        this.onOglasDeleteListener = onOglasDeleteListener;
        this.onOglasEditListener=onOglasEditListener;
    }

    @Override
    public OglasViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_oglas2, parent, false);
        return new OglasViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OglasiAdapter2.OglasViewHolder holder, int position) {
        Oglas oglas = oglasiList.get(position);

        holder.textViewLokacija.setText(oglas.getLokacija());
        holder.textViewNaselje.setText(oglas.getNaselje());
        holder.textViewCena.setText(String.valueOf(oglas.getCena()));
        holder.textViewBrojSoba.setText(String.valueOf(oglas.getBrojSoba()));
        if (oglas.getSlika() != null) {
            Bitmap bitmap = BitmapFactory.decodeByteArray(oglas.getSlika(), 0, oglas.getSlika().length);
            holder.imageViewSlika.setImageBitmap(bitmap);
        }
        holder.btnDeleteOglas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onOglasDeleteListener != null) {
                    onOglasDeleteListener.onOglasDelete(holder.getAdapterPosition());
                }
            }
        });
        holder.btnIzmeni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onOglasEditListener != null) {
                    onOglasEditListener.onOglasEdit(holder.getAdapterPosition());
                }
            }
        });

    }




    @Override
    public int getItemCount() {
        return oglasiList.size();
    }
    public void setOglasiList(List<Oglas> oglasiList) {
        this.oglasiList = oglasiList;
    }
    public List<Oglas> getOglasiList() {
        return oglasiList;
    }

    public class OglasViewHolder extends RecyclerView.ViewHolder {
        TextView textViewLokacija, textViewNaselje, textViewCena, textViewBrojSoba;
        ImageView imageViewSlika;
        Button btnDeleteOglas;
        Button btnIzmeni;

        public OglasViewHolder(View itemView) {
            super(itemView);
            textViewLokacija = itemView.findViewById(R.id.textViewLokacija);
            textViewNaselje = itemView.findViewById(R.id.textViewNaselje);
            textViewCena = itemView.findViewById(R.id.textViewCena);
            textViewBrojSoba = itemView.findViewById(R.id.textViewBrojSoba);
            imageViewSlika = itemView.findViewById(R.id.imageViewSlika);
            btnDeleteOglas = itemView.findViewById(R.id.btnObrisi);
            btnIzmeni=itemView.findViewById(R.id.btnIzmeni);
        }
    }
}
