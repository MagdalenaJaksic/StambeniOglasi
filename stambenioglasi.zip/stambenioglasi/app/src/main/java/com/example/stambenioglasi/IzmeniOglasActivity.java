package com.example.stambenioglasi;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class IzmeniOglasActivity extends AppCompatActivity {

    private EditText editTextLokacija;
    private EditText editTextNaselje;
    private EditText editTextCena;
    private EditText editTextBrojSoba;
    private EditText editTextOpis;
    private EditText editTextKontakt;
    private ImageView imageViewSlika;
    private Button btnSaveChanges;

    private DatabaseHelper databaseHelper;
    private long oglasId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.izmeni_oglas);

        editTextLokacija = findViewById(R.id.editTextLokacija);
        editTextNaselje = findViewById(R.id.editTextNaselje);
        editTextCena = findViewById(R.id.editTextCena);
        editTextBrojSoba = findViewById(R.id.editTextBrojSoba);
        editTextOpis=findViewById(R.id.editTextOpis);
        editTextKontakt=findViewById(R.id.editTextKontakt);
        imageViewSlika = findViewById(R.id.editImageViewSlika);
        btnSaveChanges = findViewById(R.id.btnSaveChanges);

        databaseHelper = new DatabaseHelper(this);

        Intent intent = getIntent();
//UZIMA SE OGLAS PREKO ID-A I STAVLJAJU SE VREDNOSTI
            oglasId = intent.getLongExtra("OGLAS_ID",-1l);
            if (oglasId != -1) {

                Oglas oglas = databaseHelper.getOglasById(oglasId);


                editTextLokacija.setText(oglas.getLokacija());
                editTextNaselje.setText(oglas.getNaselje());
                editTextCena.setText(String.valueOf(oglas.getCena()));
                editTextBrojSoba.setText(String.valueOf(oglas.getBrojSoba()));
                editTextOpis.setText(oglas.getOpis());
                editTextKontakt.setText(oglas.getKontakt());

                byte[] imageBytes = oglas.getSlika();
                if (imageBytes != null) {
                    Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
                    imageViewSlika.setImageBitmap(bitmap);
                }


                btnSaveChanges.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        saveChanges();
                    }
                });
            }
        }


    private void saveChanges() {

        String lokacija = editTextLokacija.getText().toString();
        String naselje = editTextNaselje.getText().toString();
        int cena = Integer.parseInt(editTextCena.getText().toString());
        int brojSoba = Integer.parseInt(editTextBrojSoba.getText().toString());
        String opis=editTextOpis.getText().toString();
        String kontakt=editTextKontakt.getText().toString();

        //UPDATE-UJE SE BAZA
        databaseHelper.updateOglas(oglasId, lokacija, naselje, cena, brojSoba,opis,kontakt);

       //OBAVESTAVA SE MOJ NALOG O PROMENAMA
        Intent resultIntent = new Intent();
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}
