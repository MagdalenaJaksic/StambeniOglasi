package com.example.stambenioglasi;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity{
    private static final int MOJ_NALOG_REQUEST_CODE = 1001;
    private List<Oglas> oglasiList;
    private RecyclerView recyclerViewOglasi;
    private OglasiAdapter oglasiAdapter;
    private OglasiAdapter2 oglasiAdapter2;
    private Button btnMojNalog;
    private Button btnDodajOglas;
    private Button btnFilteri;
    private Spinner spinnerSortiranje;
    DatabaseHelper databaseHelper;
    public static OnOglasChangeListener oglasChangeListener;


//ZA OSVEZAVANJE LISTE OGLASA
    private ActivityResultLauncher<Intent> mojNalogLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    List<Oglas> refreshedOglasi = databaseHelper.getAllOglasi();
                    oglasiAdapter.setOglasiList(refreshedOglasi);
                    oglasiAdapter.notifyDataSetChanged();
                }
            }
    );
//OVO JE ISTO KAO GORE
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == MOJ_NALOG_REQUEST_CODE && resultCode == RESULT_OK) {
            List<Oglas> refreshedOglasi = databaseHelper.getAllOglasi();
            oglasiAdapter.setOglasiList(refreshedOglasi);
            oglasiAdapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnDodajOglas = findViewById(R.id.btnDodajOglas);
        btnMojNalog = findViewById(R.id.btnMojNalog);
        btnFilteri = findViewById(R.id.btnFilteri);
        spinnerSortiranje = findViewById(R.id.spinnerSortiranje);
        databaseHelper = new DatabaseHelper(this);

        Intent intent = getIntent();
        String username = intent.getStringExtra("USERNAME");
        String username2=intent.getStringExtra("IME_VLASNIKA");

        recyclerViewOglasi = findViewById(R.id.recyclerViewOglasi);
        recyclerViewOglasi.setLayoutManager(new LinearLayoutManager(this));
        oglasiList = databaseHelper.getAllOglasi();
        oglasiAdapter = new OglasiAdapter(this, oglasiList);
        recyclerViewOglasi.setAdapter(oglasiAdapter);




        if (intent.hasExtra("IS_NOT_LOGGED_IN")) {

                btnDodajOglas.setVisibility(View.GONE);
                btnMojNalog.setVisibility(View.GONE);

        }

        //DODAJ OGLAS I SALJE SE KORISNICKO IME

        btnDodajOglas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, DodajOglasActivity.class);
                intent.putExtra("KORISNICKO_IME", username);
                intent.putExtra("KORISNICKO_IME2",username2);
                startActivity(intent);

            }
        });

        //MOJ NALOG I SALJE SE KORISNICKO IME

btnMojNalog.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent intentNalog=new Intent(MainActivity.this,MojNalog.class);
        intentNalog.putExtra("KORISNICKO_IME", username);
        intentNalog.putExtra("KORISNICKO_IME2",username2);

        //DA SE OBAVESTI MAIN KAD SE IZMENI OGLAS DA BI SE AZURIRAO RECYCLERVIEW
        MainActivity.oglasChangeListener = new OnOglasChangeListener() {
            @Override
            public void onOglasChanged() {
                List<Oglas> refreshedOglasi = databaseHelper.getAllOglasi();
                oglasiAdapter.setOglasiList(refreshedOglasi);
                oglasiAdapter.notifyDataSetChanged();
            }
        };
        mojNalogLauncher.launch(intentNalog);
    }
});

        btnFilteri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFiltersDialog();
            }
        });


        //ZA SORTIRANJE
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.sortiranje_niz,
                android.R.layout.simple_spinner_item
        );


        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSortiranje.setAdapter(adapter);
        spinnerSortiranje.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                sortirajOglase(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }
        });

    }

    //ZA FILTERE
    private void showFiltersDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Filteri");


        View dialogView = getLayoutInflater().inflate(R.layout.dialog_filters, null);
        builder.setView(dialogView);


        final EditText etLokacija = dialogView.findViewById(R.id.etLokacija);
        final EditText etNaselje = dialogView.findViewById(R.id.etNaselje);
        final EditText etMaxCena = dialogView.findViewById(R.id.etMaxCena);
        final EditText etMinBrojSoba = dialogView.findViewById(R.id.etMinBrojSoba);


        builder.setPositiveButton("Filtriraj", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                String lokacija = etLokacija.getText().toString();
                String naselje = etNaselje.getText().toString();
                String strMaxCena = etMaxCena.getText().toString();
                String strMinBrojSoba = etMinBrojSoba.getText().toString();

                    //AKO JE PRAZAN NA NULU AKO NE U INT
                int maxCena = strMaxCena.isEmpty() ? 0 : Integer.parseInt(strMaxCena);
                int minBrojSoba=strMinBrojSoba.isEmpty() ? 0 : Integer.parseInt(strMinBrojSoba);


                List<Oglas> kopijaOgLasiListe = new ArrayList<>(oglasiList);
                List<Oglas> filtriraniOglasi = getFilteredOglasi(lokacija, naselje,maxCena, minBrojSoba, kopijaOgLasiListe);
                oglasiAdapter.setOglasiList(filtriraniOglasi);
                oglasiAdapter.notifyDataSetChanged();
            }
        });

        builder.setNegativeButton("Otkaži", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    private List<Oglas> getFilteredOglasi(String lokacija, String naselje, int maxCena, int minBrojSoba, List<Oglas> listaoglasa) {
        List<Oglas> filtriraniOglasi = new ArrayList<>();

        for (Oglas oglas : listaoglasa) {
            boolean uslovLokacija = lokacija.isEmpty() || oglas.getLokacija().equalsIgnoreCase(lokacija);
            boolean uslovNaselje = naselje.isEmpty() || oglas.getNaselje().equalsIgnoreCase(naselje);
            boolean uslovMaxCena = maxCena <= 0 || oglas.getCena() <= maxCena;
            boolean uslovMinBrojSoba = minBrojSoba <= 0 || oglas.getBrojSoba() >= minBrojSoba;

            // BAR JEDAN OD USLOVA
            if (uslovLokacija && uslovNaselje && uslovMaxCena && uslovMinBrojSoba) {
                filtriraniOglasi.add(oglas);
            }
        }

        // SVI AKO FILTERI NISU POSTAVLJENI
        if (lokacija.isEmpty() && naselje.isEmpty() && maxCena <= 0 && minBrojSoba <= 0) {
            return listaoglasa;
        }

        return filtriraniOglasi;
    }




    private void sortirajOglase (int selectedItemPosition){
        List<Oglas> oglasi = oglasiAdapter.getOglasiList();

        switch (selectedItemPosition) {
            case 0:
                //RASTUCE
                Collections.sort(oglasi, new Comparator<Oglas>() {
                    @Override
                    public int compare(Oglas o1, Oglas o2) {
                        return Integer.compare(o1.getCena(), o2.getCena());
                    }
                });
                break;
            case 1:
                //OPADAJUCE
                Collections.sort(oglasi, new Comparator<Oglas>() {
                    @Override
                    public int compare(Oglas o1, Oglas o2) {
                        return Integer.compare(o2.getCena(), o1.getCena());
                    }
                });
                break;
        }
        oglasiAdapter.setOglasiList(oglasi);
        oglasiAdapter.notifyDataSetChanged();
    }
}


