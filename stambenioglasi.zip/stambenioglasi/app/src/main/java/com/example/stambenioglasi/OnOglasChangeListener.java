package com.example.stambenioglasi;

public interface OnOglasChangeListener {
    void onOglasChanged();
}
