package com.example.stambenioglasi;



public class Oglas {
    private long id;
    private String lokacija;
    private String naselje;
    private int cena;
    private int brojSoba;
    private String opis;
    private String kontakt;
    private String vlasnik;
    private byte[] slika;

    public String getVlasnik() {
        return vlasnik;
    }

    public void setVlasnik(String vlasnik) {
        this.vlasnik = vlasnik;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getLokacija() {
        return lokacija;
    }

    public void setLokacija(String lokacija) {
        this.lokacija = lokacija;
    }

    public String getNaselje() {
        return naselje;
    }

    public void setNaselje(String naselje) {
        this.naselje = naselje;
    }

    public int getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }

    public int getBrojSoba() {
        return brojSoba;
    }

    public void setBrojSoba(int brojSoba) {
        this.brojSoba = brojSoba;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public String getKontakt() {
        return kontakt;
    }

    public void setKontakt(String kontakt) {
        this.kontakt = kontakt;
    }

    public byte[] getSlika() {
        return slika;
    }

    public void setSlika(byte[] slika) {
        this.slika = slika;
    }


    public Oglas(long id, String lokacija, String naselje, int cena, int brojSoba, String opis, String kontakt,String vlasnik, byte[] slika) {
        this.id = id;
        this.lokacija = lokacija;
        this.naselje = naselje;
        this.cena = cena;
        this.brojSoba = brojSoba;
        this.opis = opis;
        this.kontakt = kontakt;
        this.vlasnik = vlasnik;
        this.slika = slika;
    }
}
